# Portfolio Profesional

Una aplicación de portfolio profesional con panel de administración para mostrar proyectos, habilidades y recibir mensajes de contacto.

## Características

- **Frontend**: Desarrollado con Astro.js y TailwindCSS
- **Backend**: API RESTful con Node.js, Express y MongoDB
- **Panel de Administración**: Gestión completa de proyectos, mensajes y configuración del sitio
- **Autenticación**: Sistema de login seguro con JWT
- **Carga de archivos**: Soporte para subir imágenes y documentos
- **Responsive**: Diseño adaptable a todos los dispositivos

## Estructura del Proyecto

```
/
├── backend/             # API backend con Express y MongoDB
│   ├── config/          # Configuración de la base de datos
│   ├── controllers/     # Controladores de la API
│   ├── middleware/      # Middleware personalizado
│   ├── models/          # Modelos de datos (Mongoose)
│   ├── routes/          # Rutas de la API
│   └── server.js        # Punto de entrada del servidor
├── src/                 # Frontend con Astro.js
│   ├── api/             # Configuración y utilidades para la API
│   ├── components/      # Componentes reutilizables
│   ├── layouts/         # Layouts de la aplicación
│   └── pages/           # Páginas de la aplicación
├── public/              # Archivos estáticos
└── uploads/             # Carpeta para archivos subidos
    ├── images/          # Imágenes subidas
    └── documents/       # Documentos subidos
```

## Requisitos Previos

- Node.js (v14 o superior)
- MongoDB (local o en la nube)
- npm o yarn

## Instalación

1. Clona el repositorio:
   ```bash
   git clone https://github.com/tu-usuario/portfolio-profesional.git
   cd portfolio-profesional
   ```

2. Instala las dependencias del backend:
   ```bash
   cd backend
   npm install
   ```

3. Instala las dependencias del frontend:
   ```bash
   cd ..
   npm install
   ```

4. Crea un archivo `.env` en la raíz del proyecto basado en `.env.example`:
   ```
   # URL de la API (accesible desde el frontend)
   PUBLIC_API_URL=http://localhost:5000/api

   # Puerto para el servidor de desarrollo de Astro
   PORT=4321

   # Configuración de MongoDB
   MONGODB_URI=mongodb://localhost:27017/portfolio

   # Configuración de JWT
   JWT_SECRET=tu_clave_secreta_muy_segura
   JWT_EXPIRE=30d
   ```

## Ejecución

1. Inicia el servidor backend:
   ```bash
   cd backend
   npm run dev
   ```

2. En otra terminal, inicia el servidor frontend:
   ```bash
   npm run dev
   ```

3. Accede a la aplicación:
   - Frontend: `http://localhost:4321`
   - Panel de administración: `http://localhost:4321/admin`
   - API: `http://localhost:5000/api`

## Despliegue

### Backend

1. Configura las variables de entorno en producción
2. Construye la aplicación:
   ```bash
   cd backend
   npm start
   ```

### Frontend

1. Construye la aplicación:
   ```bash
   npm run build
   ```

2. El resultado de la compilación estará en la carpeta `dist/` listo para ser desplegado en cualquier servidor web estático.

## Usuario Administrador Inicial

Para crear un usuario administrador inicial, puedes usar la siguiente ruta:

```
POST /api/users/register
{
  "name": "Admin",
  "email": "admin@example.com",
  "password": "admin123",
  "isAdmin": true
}
```

## Licencia

MIT

```sh
npm create astro@latest -- --template basics
```

[![Open in StackBlitz](https://developer.stackblitz.com/img/open_in_stackblitz.svg)](https://stackblitz.com/github/withastro/astro/tree/latest/examples/basics)
[![Open with CodeSandbox](https://assets.codesandbox.io/github/button-edit-lime.svg)](https://codesandbox.io/p/sandbox/github/withastro/astro/tree/latest/examples/basics)
[![Open in GitHub Codespaces](https://github.com/codespaces/badge.svg)](https://codespaces.new/withastro/astro?devcontainer_path=.devcontainer/basics/devcontainer.json)

> 🧑‍🚀 **Seasoned astronaut?** Delete this file. Have fun!

![just-the-basics](https://github.com/withastro/astro/assets/2244813/a0a5533c-a856-4198-8470-2d67b1d7c554)

## 🚀 Project Structure

Inside of your Astro project, you'll see the following folders and files:

```text
/
├── public/
│   └── favicon.svg
├── src/
│   ├── layouts/
│   │   └── Layout.astro
│   └── pages/
│       └── index.astro
└── package.json
```

To learn more about the folder structure of an Astro project, refer to [our guide on project structure](https://docs.astro.build/en/basics/project-structure/).

## 🧞 Commands

All commands are run from the root of the project, from a terminal:

| Command                   | Action                                           |
| :------------------------ | :----------------------------------------------- |
| `npm install`             | Installs dependencies                            |
| `npm run dev`             | Starts local dev server at `localhost:4321`      |
| `npm run build`           | Build your production site to `./dist/`          |
| `npm run preview`         | Preview your build locally, before deploying     |
| `npm run astro ...`       | Run CLI commands like `astro add`, `astro check` |
| `npm run astro -- --help` | Get help using the Astro CLI                     |

## 👀 Want to learn more?

Feel free to check [our documentation](https://docs.astro.build) or jump into our [Discord server](https://astro.build/chat).
